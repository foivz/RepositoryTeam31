﻿namespace Bastion
{
    partial class administrator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uREDIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.djelatniciToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dodajToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.urediToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.izbrisiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.artikliToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dodajToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.urediToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.izbrisiToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.naruciToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eVIDENCIJAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.obracuniToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.popisNarudzbiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iZVJESTAJIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.brojGostijuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zaradaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.najprodavanijiArtiklToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oDJAVAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.popisDjelatnikaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.popisArtikalaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.uREDIToolStripMenuItem,
            this.eVIDENCIJAToolStripMenuItem,
            this.iZVJESTAJIToolStripMenuItem,
            this.oDJAVAToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(877, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.fileToolStripMenuItem.Text = "DATOTEKA";
            this.fileToolStripMenuItem.Click += new System.EventHandler(this.fileToolStripMenuItem_Click);
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.openToolStripMenuItem.Text = "Otvori";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.exitToolStripMenuItem.Text = "Zatvori";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // uREDIToolStripMenuItem
            // 
            this.uREDIToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.djelatniciToolStripMenuItem,
            this.artikliToolStripMenuItem});
            this.uREDIToolStripMenuItem.Name = "uREDIToolStripMenuItem";
            this.uREDIToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
            this.uREDIToolStripMenuItem.Text = "UREDI";
            // 
            // djelatniciToolStripMenuItem
            // 
            this.djelatniciToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dodajToolStripMenuItem,
            this.urediToolStripMenuItem1,
            this.izbrisiToolStripMenuItem,
            this.popisDjelatnikaToolStripMenuItem});
            this.djelatniciToolStripMenuItem.Name = "djelatniciToolStripMenuItem";
            this.djelatniciToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.djelatniciToolStripMenuItem.Text = "Djelatnici";
            // 
            // dodajToolStripMenuItem
            // 
            this.dodajToolStripMenuItem.Name = "dodajToolStripMenuItem";
            this.dodajToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.dodajToolStripMenuItem.Text = "Dodaj";
            this.dodajToolStripMenuItem.Click += new System.EventHandler(this.dodajToolStripMenuItem_Click);
            // 
            // urediToolStripMenuItem1
            // 
            this.urediToolStripMenuItem1.Name = "urediToolStripMenuItem1";
            this.urediToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.urediToolStripMenuItem1.Text = "Uredi";
            // 
            // izbrisiToolStripMenuItem
            // 
            this.izbrisiToolStripMenuItem.Name = "izbrisiToolStripMenuItem";
            this.izbrisiToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.izbrisiToolStripMenuItem.Text = "Izbrisi";
            // 
            // artikliToolStripMenuItem
            // 
            this.artikliToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dodajToolStripMenuItem1,
            this.urediToolStripMenuItem2,
            this.izbrisiToolStripMenuItem1,
            this.naruciToolStripMenuItem,
            this.popisArtikalaToolStripMenuItem});
            this.artikliToolStripMenuItem.Name = "artikliToolStripMenuItem";
            this.artikliToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.artikliToolStripMenuItem.Text = "Artikli";
            // 
            // dodajToolStripMenuItem1
            // 
            this.dodajToolStripMenuItem1.Name = "dodajToolStripMenuItem1";
            this.dodajToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.dodajToolStripMenuItem1.Text = "Dodaj";
            this.dodajToolStripMenuItem1.Click += new System.EventHandler(this.dodajToolStripMenuItem1_Click);
            // 
            // urediToolStripMenuItem2
            // 
            this.urediToolStripMenuItem2.Name = "urediToolStripMenuItem2";
            this.urediToolStripMenuItem2.Size = new System.Drawing.Size(152, 22);
            this.urediToolStripMenuItem2.Text = "Uredi";
            // 
            // izbrisiToolStripMenuItem1
            // 
            this.izbrisiToolStripMenuItem1.Name = "izbrisiToolStripMenuItem1";
            this.izbrisiToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.izbrisiToolStripMenuItem1.Text = "Izbrisi";
            // 
            // naruciToolStripMenuItem
            // 
            this.naruciToolStripMenuItem.Name = "naruciToolStripMenuItem";
            this.naruciToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.naruciToolStripMenuItem.Text = "Naruci";
            // 
            // eVIDENCIJAToolStripMenuItem
            // 
            this.eVIDENCIJAToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.obracuniToolStripMenuItem,
            this.popisNarudzbiToolStripMenuItem});
            this.eVIDENCIJAToolStripMenuItem.Name = "eVIDENCIJAToolStripMenuItem";
            this.eVIDENCIJAToolStripMenuItem.Size = new System.Drawing.Size(81, 20);
            this.eVIDENCIJAToolStripMenuItem.Text = "EVIDENCIJA";
            // 
            // obracuniToolStripMenuItem
            // 
            this.obracuniToolStripMenuItem.Name = "obracuniToolStripMenuItem";
            this.obracuniToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.obracuniToolStripMenuItem.Text = "Obracuni";
            // 
            // popisNarudzbiToolStripMenuItem
            // 
            this.popisNarudzbiToolStripMenuItem.Name = "popisNarudzbiToolStripMenuItem";
            this.popisNarudzbiToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.popisNarudzbiToolStripMenuItem.Text = "Popis narudzbi";
            // 
            // iZVJESTAJIToolStripMenuItem
            // 
            this.iZVJESTAJIToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.brojGostijuToolStripMenuItem,
            this.zaradaToolStripMenuItem,
            this.najprodavanijiArtiklToolStripMenuItem});
            this.iZVJESTAJIToolStripMenuItem.Name = "iZVJESTAJIToolStripMenuItem";
            this.iZVJESTAJIToolStripMenuItem.Size = new System.Drawing.Size(74, 20);
            this.iZVJESTAJIToolStripMenuItem.Text = "IZVJESTAJI";
            // 
            // brojGostijuToolStripMenuItem
            // 
            this.brojGostijuToolStripMenuItem.Name = "brojGostijuToolStripMenuItem";
            this.brojGostijuToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.brojGostijuToolStripMenuItem.Text = "Broj gostiju";
            // 
            // zaradaToolStripMenuItem
            // 
            this.zaradaToolStripMenuItem.Name = "zaradaToolStripMenuItem";
            this.zaradaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.zaradaToolStripMenuItem.Text = "Zarada";
            // 
            // najprodavanijiArtiklToolStripMenuItem
            // 
            this.najprodavanijiArtiklToolStripMenuItem.Name = "najprodavanijiArtiklToolStripMenuItem";
            this.najprodavanijiArtiklToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.najprodavanijiArtiklToolStripMenuItem.Text = "Najprodavaniji artikl";
            // 
            // oDJAVAToolStripMenuItem
            // 
            this.oDJAVAToolStripMenuItem.Name = "oDJAVAToolStripMenuItem";
            this.oDJAVAToolStripMenuItem.Size = new System.Drawing.Size(63, 20);
            this.oDJAVAToolStripMenuItem.Text = "ODJAVA";
            this.oDJAVAToolStripMenuItem.Click += new System.EventHandler(this.oDJAVAToolStripMenuItem_Click);
            // 
            // popisDjelatnikaToolStripMenuItem
            // 
            this.popisDjelatnikaToolStripMenuItem.Name = "popisDjelatnikaToolStripMenuItem";
            this.popisDjelatnikaToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.popisDjelatnikaToolStripMenuItem.Text = "Popis djelatnika";
            this.popisDjelatnikaToolStripMenuItem.Click += new System.EventHandler(this.popisDjelatnikaToolStripMenuItem_Click);
            // 
            // popisArtikalaToolStripMenuItem
            // 
            this.popisArtikalaToolStripMenuItem.Name = "popisArtikalaToolStripMenuItem";
            this.popisArtikalaToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.popisArtikalaToolStripMenuItem.Text = "Popis artikala";
            this.popisArtikalaToolStripMenuItem.Click += new System.EventHandler(this.popisArtikalaToolStripMenuItem_Click);
            // 
            // administrator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(877, 441);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "administrator";
            this.Text = "administrator";
            this.Load += new System.EventHandler(this.administrator_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uREDIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem djelatniciToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dodajToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem urediToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem izbrisiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem artikliToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dodajToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem urediToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem izbrisiToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem naruciToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eVIDENCIJAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem obracuniToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem popisNarudzbiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iZVJESTAJIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem brojGostijuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zaradaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem najprodavanijiArtiklToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oDJAVAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem popisDjelatnikaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem popisArtikalaToolStripMenuItem;


    }
}